# India Research Jobs Tracker (Biology/Life Sciences/Biotech)

This toolkit helps you **frequently check JRF & project positions in India** (Govt/Private funding) with:
- Programmable meta-search (Google CSE, optional Bing)
- Keyword filters (JRF, Project Assistant, SRF, RA, PA, Project Fellow, Project Associate, Research Fellow)
- Institute/domain scoping (IISc, IITs, IISERs, NIPERs, CSIR labs, ICMR, DBT, Central/State Universities, etc.)
- Scoring + deduplication
- Outputs to CSV/JSON/Markdown
- Optional Telegram/email notifications
- Streamlit UI to search saved results
- GitHub Actions workflow for daily runs

> Minimal effort path: use **Google Programmable Search Engine** (free/cheap) + Telegram notifications. Scraping is brittle; search APIs are more robust.

---

## Quick start

1. **Create a Google Programmable Search Engine (PSE):**
   - https://programmablesearchengine.google.com/
   - Choose *"Sites to search"* and paste domains from `configs/institutions.yaml` (you can add/remove anytime).
   - In *Control Panel → Basics*, get the **Search engine ID** (CX).
   - In Google Cloud Console, enable **Custom Search JSON API** and create an **API key**.

2. **(Optional) Bing Web Search API:**
   - Create an API key from Azure portal if you want redundancy.

3. **(Optional) Telegram notifications:**
   - Create a bot with @BotFather → get `TELEGRAM_BOT_TOKEN`.
   - Start a chat with the bot and send any message, then use `@userinfobot` to get your `TELEGRAM_CHAT_ID`.

4. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

5. **Configure settings:**
   - Edit `configs/config.yaml` with your API keys, preferences, and keywords.
   - Edit `configs/institutions.yaml` to select which domains to search.
   - Edit `configs/keywords.yaml` if you want custom include/exclude filters.

6. **Run a search now:**
   ```bash
   python tracker/india_research_jobs.py --days 7 --limit 100
   ```

   Outputs in `data/`:
   - `jobs.csv` — spreadsheet friendly
   - `jobs.json` — machine-readable
   - `jobs.md` — nicely formatted list (for sharing)
   - `last_run.log` — run summary

7. **Open the local UI:**
   ```bash
   streamlit run streamlit_app.py
   ```

8. **Automate (GitHub Actions, daily at 08:00 IST):**
   - Push this repo to GitHub.
   - Add repository secrets for your keys (see comments inside workflow).
   - The included workflow will run on a cron and commit new results.

---

## How it works

- Uses Google PSE to fetch fresh results from curated Indian research/academic domains.
- Filters by recency window (`--days`) and by keywords.
- Scores and deduplicates results by URL/title fingerprint.
- Saves to `data/` and (optionally) notifies you of **new** hits since the last run.

## Notes & tips

- Keep domain list high quality to minimize noise.
- Prefer API search over deep scraping; add site-specific scrapers only if necessary.
- Tune keywords in `configs/keywords.yaml` (e.g., add `walk-in`, `advt`, `project fellow`, etc.).
- You can add a **"private"** section of domains (startups, NGOs, CROs) as you discover them.
