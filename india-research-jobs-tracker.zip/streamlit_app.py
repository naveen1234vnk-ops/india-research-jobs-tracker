# streamlit_app.py
import streamlit as st
import pandas as pd
import json, os
from tracker.engine import now_ist

st.set_page_config(page_title="India JRF/Project Jobs Tracker", layout="wide")

st.title("🔎 India JRF / Project Positions — Browser")
st.caption("Biology • Life Sciences • Biotechnology")

data_path = st.sidebar.text_input("Data file (JSON)", value="data/jobs.json")

df = pd.DataFrame()
if os.path.exists(data_path):
    with open(data_path, "r", encoding="utf-8") as f:
        rows = json.load(f)
    df = pd.DataFrame(rows)

st.sidebar.write("Filters")
kw = st.sidebar.text_input("Keyword contains", value="")
dom = st.sidebar.text_input("Domain contains", value="")
min_score = st.sidebar.slider("Min score", 0.0, 10.0, 0.2, 0.1)

if not df.empty:
    if kw:
        df = df[df["title"].str.contains(kw, case=False, na=False) | df["snippet"].str.contains(kw, case=False, na=False)]
    if dom:
        df = df[df["source_domain"].str.contains(dom, case=False, na=False)]
    df = df[df["score"] >= min_score]
    df = df.sort_values(by="score", ascending=False)

st.write(f"Updated: {now_ist().strftime('%Y-%m-%d %H:%M IST')} • {len(df)} results")
st.dataframe(df[["title","url","source_domain","score"]], use_container_width=True, height=520)
