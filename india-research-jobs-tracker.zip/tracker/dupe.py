# tracker/dupe.py
from __future__ import annotations
import json, os
from .utils import fingerprint

def load_previous(path: str) -> dict[str, dict]:
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            rows = json.load(f)
        return { r.get("fingerprint",""): r for r in rows if isinstance(r, dict) }
    except Exception:
        return {}

def partition_new(all_records: list[dict], prev: dict[str, dict]) -> tuple[list[dict], list[dict]]:
    new, existing = [], []
    for r in all_records:
        fp = r.get("fingerprint","")
        if fp and fp not in prev:
            new.append(r)
        else:
            existing.append(r)
    return new, existing
