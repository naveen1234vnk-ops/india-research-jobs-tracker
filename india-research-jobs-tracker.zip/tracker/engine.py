# tracker/engine.py
from __future__ import annotations
import os, requests, time
from dateutil import tz
from datetime import datetime, timedelta
from urllib.parse import urlencode
from .utils import env_or_value, fingerprint, score_record, domain

def now_ist():
    return datetime.now(tz.gettz("Asia/Kolkata"))

def google_search(api_key: str, cx: str, query: str, num: int = 10, start: int = 1):
    base = "https://www.googleapis.com/customsearch/v1"
    params = {"key": api_key, "cx": cx, "q": query, "num": num, "start": start, "sort": "date"}
    r = requests.get(base, params=params, timeout=20)
    r.raise_for_status()
    return r.json()

def bing_search(api_key: str, endpoint: str, query: str, count: int = 10, offset: int = 0):
    headers = {"Ocp-Apim-Subscription-Key": api_key}
    params = {"q": query, "count": count, "offset": offset, "mkt": "en-IN", "freshness": "Month", "textDecorations": False, "textFormat": "Raw"}
    r = requests.get(endpoint, headers=headers, params=params, timeout=20)
    r.raise_for_status()
    return r.json()

def build_query(includes: list[str], domains: list[str]) -> str:
    inc = " OR ".join([f'"{w}"' if " " in w else w for w in includes])
    ds  = " OR ".join([f"site:{d}" for d in domains])
    return f"({inc}) ({ds})"

def normalize_google_items(items: list[dict]) -> list[dict]:
    out = []
    for it in items or []:
        link = it.get("link")
        title = it.get("title") or ""
        snippet = it.get("snippet") or ""
        out.append({"url": link, "title": title, "snippet": snippet})
    return out

def normalize_bing_items(resp: dict) -> list[dict]:
    out = []
    for it in (resp.get("webPages", {}) or {}).get("value", []):
        out.append({"url": it.get("url"), "title": it.get("name") or "", "snippet": it.get("snippet") or ""})
    return out

def run_search(config: dict, include_kw: list[str], exclude_kw: list[str], domains: list[str], days: int, limit: int, min_score: float):
    google_api_key = env_or_value(config.get("google_api_key"))
    google_cx = env_or_value(config.get("google_cx"))
    use_bing = bool(config.get("use_bing"))
    bing_api_key = env_or_value(config.get("bing_api_key"))
    bing_endpoint = config.get("bing_endpoint", "https://api.bing.microsoft.com/v7.0/search")

    query = build_query(include_kw, domains)
    records = []

    # Google first
    if google_api_key and google_cx:
        start = 1
        page_size = 10
        while len(records) < limit:
            resp = google_search(google_api_key, google_cx, query, num=page_size, start=start)
            items = normalize_google_items(resp.get("items", []))
            if not items:
                break
            records.extend(items)
            start += page_size
            time.sleep(0.2)  # be polite

    # Optional: Bing supplement
    if use_bing and bing_api_key:
        offset = 0
        page_size = 15
        while len(records) < limit:
            resp = bing_search(bing_api_key, bing_endpoint, query, count=page_size, offset=offset)
            items = normalize_bing_items(resp)
            if not items:
                break
            records.extend(items)
            offset += page_size
            time.sleep(0.2)

    # Trim to limit
    records = records[:limit]

    # Score + fingerprint
    out = []
    for r in records:
        r["source_domain"] = domain(r.get("url",""))
        r["score"] = score_record(r, include_kw, exclude_kw)
        r["fingerprint"] = fingerprint(r)
        out.append(r)

    # Filter by min_score
    out = [r for r in out if r.get("score", 0) >= float(min_score)]
    return out
