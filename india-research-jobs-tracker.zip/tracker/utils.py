# tracker/utils.py
from __future__ import annotations
import os, hashlib, re
from urllib.parse import urlparse

def env_or_value(val: str | None) -> str | None:
    if not isinstance(val, str):
        return val
    # Expand ${VARNAME} env templates
    m = re.match(r'^\$\{([A-Za-z_][A-Za-z0-9_]*)\}$', val.strip())
    if m:
        return os.environ.get(m.group(1))
    return val

def fingerprint(record: dict) -> str:
    base = (record.get("url","") + "|" + record.get("title","")).lower().strip()
    return hashlib.sha256(base.encode("utf-8")).hexdigest()

def domain(url: str) -> str:
    try:
        return urlparse(url).netloc
    except Exception:
        return ""

def score_record(rec: dict, include_kw: list[str], exclude_kw: list[str]) -> float:
    text = f"{rec.get('title','')} {rec.get('snippet','')}".lower()
    score = 0.0
    for w in include_kw:
        if w.lower() in text:
            score += 1.0
    for w in exclude_kw:
        if w.lower() in text:
            score -= 2.0
    # boost if title includes 'JRF'/'Project'
    t = rec.get("title","").lower()
    for b in ["jrf", "junior research fellow", "project assistant", "project associate", "srf"]:
        if b in t:
            score += 1.5
    return score
