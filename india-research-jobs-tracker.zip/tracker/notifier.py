# tracker/notifier.py
from __future__ import annotations
import smtplib, os, json, ssl, requests

def notify_telegram(bot_token: str, chat_id: str, messages: list[str]):
    if not bot_token or not chat_id or not messages:
        return
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    for m in messages:
        try:
            requests.post(url, json={"chat_id": chat_id, "text": m[:4000], "disable_web_page_preview": True}, timeout=10)
        except Exception:
            pass

def notify_email(smtp_host: str, smtp_port: int, smtp_user: str, smtp_pass: str, to_addr: str, subject: str, body: str):
    if not (smtp_host and smtp_user and smtp_pass and to_addr):
        return
    msg = f"From: {smtp_user}\r\nTo: {to_addr}\r\nSubject: {subject}\r\n\r\n{body}"
    ctx = ssl.create_default_context()
    with smtplib.SMTP(smtp_host, smtp_port) as server:
        server.starttls(context=ctx)
        server.login(smtp_user, smtp_pass)
        server.sendmail(smtp_user, [to_addr], msg.encode("utf-8"))
