# tracker/india_research_jobs.py
from __future__ import annotations
import argparse, json, os, yaml, pandas as pd
from datetime import datetime
from rich.console import Console
from rich.table import Table

from .engine import run_search, now_ist
from .dupe import load_previous, partition_new
from .notifier import notify_telegram, notify_email

def load_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def save_outputs(save_dir: str, rows: list[dict]):
    os.makedirs(save_dir, exist_ok=True)
    ts = now_ist().strftime("%Y-%m-%d %H:%M IST")
    # JSON
    jpath = os.path.join(save_dir, "jobs.json")
    with open(jpath, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    # CSV
    cpath = os.path.join(save_dir, "jobs.csv")
    pd.DataFrame(rows).to_csv(cpath, index=False)
    # Markdown
    mpath = os.path.join(save_dir, "jobs.md")
    with open(mpath, "w", encoding="utf-8") as f:
        f.write(f"# JRF / Project Positions — updated {ts}\n\n")
        for r in rows:
            f.write(f"- **{r.get('title','(no title)')}**  \n  {r.get('url','')}  \n  _Score: {r.get('score',0):.2f}, Source: {r.get('source_domain','')}_\n\n")
    return jpath, cpath, mpath

def print_table(rows: list[dict], max_rows: int = 20):
    console = Console()
    table = Table(show_header=True, header_style="bold")
    table.add_column("Title", width=60)
    table.add_column("Domain", width=25)
    table.add_column("Score", width=8, justify="right")
    for r in rows[:max_rows]:
        table.add_row(r.get("title","")[:120], r.get("source_domain",""), f"{r.get('score',0):.2f}")
    console.print(table)

def main():
    ap = argparse.ArgumentParser(description="India JRF/Project positions tracker")
    ap.add_argument("--config", default="configs/config.yaml")
    ap.add_argument("--institutions", default="configs/institutions.yaml")
    ap.add_argument("--keywords", default="configs/keywords.yaml")
    ap.add_argument("--days", type=int, default=None, help="Lookback window")
    ap.add_argument("--limit", type=int, default=None, help="Max results")
    ap.add_argument("--min-score", type=float, default=None, help="Minimum relevance score to keep")
    args = ap.parse_args()

    cfg = load_yaml(args.config)
    inst = load_yaml(args.institutions)
    kw = load_yaml(args.keywords)

    days = args.days if args.days is not None else cfg.get("search",{}).get("days", 7)
    limit = args.limit if args.limit is not None else cfg.get("search",{}).get("limit", 100)
    min_score = args.min_score if args.min_score is not None else cfg.get("search",{}).get("min_score", 0.2)

    include_kw = kw.get("include", [])
    exclude_kw = kw.get("exclude", [])
    domains = inst.get("domains", [])

    results = run_search(cfg, include_kw, exclude_kw, domains, days=days, limit=limit, min_score=min_score)

    save_dir = cfg.get("search",{}).get("save_dir","data")
    prev_map = load_previous(os.path.join(save_dir, "jobs.json"))
    new_rows, existing_rows = partition_new(results, prev_map)

    # Save merged: prefer latest score/title/snippet for duplicates
    merged = { r["fingerprint"]: r for r in (list(prev_map.values()) + results)}
    merged_rows = list(merged.values())

    jpath, cpath, mpath = save_outputs(save_dir, merged_rows)

    # Notify only about new rows
    msgs = [f"NEW: {r.get('title','')}\\n{r.get('url','')}" for r in new_rows]
    ncfg = cfg.get("notify",{})
    tcfg = ncfg.get("telegram",{})
    if tcfg.get("enabled"):
        notify_telegram(tcfg.get("bot_token"), tcfg.get("chat_id"), msgs[:25])

    ecfg = ncfg.get("email",{})
    if ecfg.get("enabled"):
        body = "\\n\\n".join(msgs[:50]) or "No new results in this run."
        notify_email(ecfg.get("smtp_host"), int(ecfg.get("smtp_port",587)), ecfg.get("smtp_user"), ecfg.get("smtp_pass"), ecfg.get("to"),
                     subject="JRF/Project Positions — New Results", body=body)

    # Console summary
    print_table(new_rows if new_rows else results)

    # Log
    with open(os.path.join(save_dir, "last_run.log"), "w", encoding="utf-8") as f:
        f.write(f"Ran at: {now_ist()}\\n")
        f.write(f"Fetched: {len(results)}\\n")
        f.write(f"New: {len(new_rows)}\\n")
        f.write(f"Saved: {len(merged_rows)}\\n")
        f.write(f"Outputs: {jpath}, {cpath}, {mpath}\\n")

if __name__ == "__main__":
    main()
